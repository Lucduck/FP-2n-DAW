/* 
 * Lucas Pérez González
 * Primer Examen
 */
var cadena = prompt("Escriu alguna cosa:");

var maFinestra = window.open("","Examen_Lucas","width=" + screen.width/2 + " height = " + screen.height/2);

var miDocument = maFinestra.document;

//Mostrar en un paràgraf la cadena escrita
var paragraf1 = miDocument.createElement("p");
paragraf1.appendChild(miDocument.createTextNode(cadena));

miDocument.body.appendChild(paragraf1);

//Mostrar en un paràgraf la parala més llarga
var paragraf2 = miDocument.createElement("p");
paragraf2.appendChild(miDocument.createTextNode("La paraula més llarga és " + paraulaMesLlarga(cadena)));

miDocument.body.appendChild(paragraf2);

//Mostrar en un segon paràgraf el numero de lletres que hi ha
var paragraf3 = miDocument.createElement("p");
paragraf3.appendChild(miDocument.createTextNode("La cadena té " + numLletres(cadena) + " lletres"));

miDocument.body.appendChild(paragraf3);


function paraulaMesLlarga(cadena){
    var x = 1;
    var cadena_llarga = "";
    while(x!=cadena.length){
        //is hi ha espai, continuo buscan paraules, sino mira la ultima paraula que queda, i després acaba
        if(cadena.indexOf(" ",x) != -1){
            var paraula = cadena.substring(x-1,cadena.indexOf(" ",x));
            if(paraula.length > cadena_llarga.length){
                cadena_llarga = paraula;
            }
            x = cadena.indexOf(" ",x)+1;
        }else{
            var final = cadena.substring(x-1,cadena.length);
            if(final.length > cadena_llarga.length){
                cadena_llarga = paraula;
            }
            x=cadena.length;
        }
    }
    //Retorna un String de la paraula més llarga
    return cadena_llarga;
}
function numLletres(cadena){
    //Paso a minuscules tota la cadena
    cadena = cadena.toLowerCase();
    var contador = 0;
    for(var i = 0; i <cadena.length; i++){
        var caracter = cadena.charCodeAt(i);
        /*
        * Si el caracter esta entre "a = 97" i "z = 122" o entre "à = 224" i "ÿ = 255"
        * Significa que es una lletra i sumo 1 al contador
        */
        if(caracter >= 97 && caracter <= 122 || caracter >= 224 && caracter <= 255){
            contador++;
        }
    }
    //Retorna el numero de vegades que ha trobat una lletra
    return contador;
}