//css per crear els borders de la taula
document.write("<style>\n\
                    table, th, td{\n\
                        border: 1px solid black;\n\
                        padding: 2px;\n\
                    } \n\
                </style>");

//Crec la variable data
var data = new Date();
data.setDate(1);
data.setMonth(1);
data.setDate(data.getDate()-1);
data.setFullYear(2017);

//TABLE HTML
//Començo la taula 
document.write("<table>\n\
                    <tr>\n\
                        <th>Data</th>\n\
                        <th>Lloc</th>\n\
                        <th>+Info</th>\n\
                    </tr>");

while(data.getFullYear()==2017){
    var ultimDia = data.getDate(); //guardo el ultim dia per recordarma
    
    //mentres no sigui divendres, resto 1
    while(data.getDay()!=5){
        data.setDate(data.getDate()-1);
    }
    
    var lloc = "";
    var info = "";
    
    //Comprovo hon és el lloc
    if(ultimDia == data.getDate()){
        lloc = "Institut";
    }else{
        lloc = "Centre Civic";
    }
    
    //Mira si és una Xerrada
    if(data.getDate()%3 == 0){
        if(lloc != "Institut")
            info = "Xerrada";
    }
    
    //Escriu tot en el taula
    document.write("<tr>\n\
                        <td>"+data.getDate()+"/"+(data.getMonth()+1)+"/"+data.getFullYear()+"</td>\n\
                        <td>"+lloc+"</td>\n\
                        <td>"+info+"</td>\n\
                    </tr>");
    
    
    //Canvio al ultim dia del mes seguent
    data.setMonth(data.getMonth()+2);
    data.setDate(1);
    data.setDate(data.getDate()-1);
}
document.write("</table>");//tanco la taula