/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tasca1;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;

/**
 *
 * @author Maribel
 */
public class Equips {
    private ResultSet ResultatSet;
    
    public void obtenirEquips(){
        String query = Equip.crearConsulta();
        ResultatSet = JavaConnection.executarConsultaSeleccio(query);
    }
    
    public void obtenirEquips(int id_equip) {
        ArrayList<String> camps = new ArrayList();
        camps.add(Equip.E_ID);
        
        String query = Equip.crearConsulta(camps);
        ResultatSet = JavaConnection.executarConsultaSeleccio(query, id_equip);
    }
    
    public Equip primer() throws SQLException{
        if(ResultatSet != null && !ResultatSet.isClosed()){
            ResultatSet.first();
        }
        return actual();
    }
    
    public Equip ultim() throws SQLException{
        if(ResultatSet != null && !ResultatSet.isClosed()){
            ResultatSet.last();
        }
        return actual();
    }
    
    public Equip anterior() throws SQLException{
        if(ResultatSet != null && !ResultatSet.isClosed() && !ResultatSet.isBeforeFirst()){
            ResultatSet.previous();
        }
        return actual();
    }
    
    public Equip posterior() throws SQLException{
        if(ResultatSet != null && !ResultatSet.isClosed() && !ResultatSet.isAfterLast()){
            ResultatSet.next();
        }
        return actual();
    }
    
    public Equip actual() throws SQLException{
        Equip equip = null;
        
        if(ResultatSet != null && !ResultatSet.isClosed() && !ResultatSet.isAfterLast() && !ResultatSet.isBeforeFirst()){
            equip = new Equip();
            equip.setId_equip(ResultatSet.getInt(Equip.E_ID));
            equip.setNom_equip(ResultatSet.getString(Equip.E_NOM));
            equip.setEstadi(ResultatSet.getString(Equip.E_ESTADI));
            equip.setPoblacio(ResultatSet.getString(Equip.E_POBL));
            equip.setCodiPostal(ResultatSet.getString(Equip.E_CP));
        }
        
        return equip;
    }
    
    public void afegirEquip(Equip equip) throws SQLException{
        if(ResultatSet != null && !ResultatSet.isClosed()){
            ResultatSet.moveToInsertRow();

            ResultatSet.updateInt(Equip.E_ID, equip.getId_equip());
            ResultatSet.updateString(Equip.E_NOM, equip.getNom_equip());
            ResultatSet.updateString(Equip.E_ESTADI, equip.getEstadi());
            ResultatSet.updateString(Equip.E_POBL, equip.getPoblacio());
            ResultatSet.updateString(Equip.E_CP, equip.getCodiPostal());
        }
    }
    
    public void eliminarEquip() throws SQLException{
        if(ResultatSet != null && !ResultatSet.isClosed()){
            ResultatSet.deleteRow();
        }
    }
    
    public void tancar() throws SQLException{
        if(ResultatSet != null && !ResultatSet.isClosed()){
            ResultatSet.close();
        }
    }
}
