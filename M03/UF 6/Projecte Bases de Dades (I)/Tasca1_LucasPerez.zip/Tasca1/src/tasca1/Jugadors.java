/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tasca1;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;

/**
 *
 * @author Maribel
 */
public class Jugadors {
    private ResultSet ResultatSet;
    
    public void obtenirJugadors(){
        String query = Jugador.crearConsulta();
        ResultatSet = JavaConnection.executarConsultaSeleccio(query);
    }
    
    public void obtenirJugadorsByEquip(int id_equip) {
        ArrayList<String> camps = new ArrayList();
        camps.add(Jugador.J_EQ_ID);
        
        String query = Jugador.crearConsulta(camps);
        ResultatSet = JavaConnection.executarConsultaSeleccio(query, id_equip);
    }
    
    public Jugador primer() throws SQLException{
        if(ResultatSet != null && !ResultatSet.isClosed()){
            ResultatSet.first();
        }
        return actual();
    }
    
    public Jugador ultim() throws SQLException{
        if(ResultatSet != null && !ResultatSet.isClosed()){
            ResultatSet.last();
        }
        return actual();
    }
    
    public Jugador anterior() throws SQLException{
        if(ResultatSet != null && !ResultatSet.isClosed() && !ResultatSet.isBeforeFirst()){
            ResultatSet.previous();
        }
        return actual();
    }
    
    public Jugador posterior() throws SQLException{
        if(ResultatSet != null && !ResultatSet.isClosed() && !ResultatSet.isAfterLast()){
            ResultatSet.next();
        }
        return actual();
    }
    
    public Jugador actual() throws SQLException{
        Jugador jdr = null;
        
        if(ResultatSet != null && !ResultatSet.isClosed() && !ResultatSet.isAfterLast() && !ResultatSet.isBeforeFirst()){
            jdr = new Jugador();
            jdr.setJug_id(ResultatSet.getInt(Jugador.J_ID));
            jdr.setEq_id(ResultatSet.getInt(Jugador.J_EQ_ID));
            jdr.setJug_nom(ResultatSet.getString(Jugador.J_NOM));
            jdr.setDorsal(ResultatSet.getInt(Jugador.J_DORSAL));
            jdr.setEdat(ResultatSet.getInt(Jugador.J_EDAT));
        }
        
        return jdr;
    }
    
    public void afegirJugador(Jugador jdr) throws SQLException{
        if(ResultatSet != null && !ResultatSet.isClosed()){
            ResultatSet.moveToInsertRow();

            ResultatSet.updateInt(Jugador.J_ID, jdr.getJug_id());
            ResultatSet.updateInt(Jugador.J_EQ_ID, jdr.getEq_id());
            ResultatSet.updateString(Jugador.J_NOM, jdr.getJug_nom());
            ResultatSet.updateInt(Jugador.J_DORSAL, jdr.getDorsal());
            ResultatSet.updateInt(Jugador.J_EDAT, jdr.getEdat());
        }
    }
    
    public void eliminarJugador() throws SQLException{
        if(ResultatSet != null && !ResultatSet.isClosed()){
            ResultatSet.deleteRow();
        }
    }
    
    public void tancar() throws SQLException{
        if(ResultatSet != null && !ResultatSet.isClosed()){
            ResultatSet.close();
        }
    }
}
