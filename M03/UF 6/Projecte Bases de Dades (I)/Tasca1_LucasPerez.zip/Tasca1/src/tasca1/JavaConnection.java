/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tasca1;

/**
 *
 * @author Maribel
 */
import javax.swing.JOptionPane;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;

public class JavaConnection {
    
    private static Connection conn = null;
    
    public static Connection getConnexio(){
        try{
            if(conn == null || conn.isClosed()){
                //Carreguem i registrem els drivers d'Oracle 
                //(seria el mateix que fer un new OracleDriver...
                Class.forName("oracle.jdbc.OracleDriver");
                //Obre la connexió a la base de dades
                //conn = DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:3521:XE", "cirvi", "cirvi");
                conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "system", "lucas");
            }
        } catch (ClassNotFoundException | SQLException ex){
             JOptionPane.showMessageDialog(null, ex);
        }
        return conn;
    }
    
    public static ResultSet executarConsultaSeleccio(String query){
        Statement select = null;
        ResultSet rs = null;
        try{
            //getConnexio();
            select = getConnexio().createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
            rs = select.executeQuery(query);
        }catch (SQLException ex){
             JOptionPane.showMessageDialog(null,ex);           
        } finally{}
        
        return rs;
    }
    
    public static ResultSet executarConsultaSeleccio(String query, int id){
        PreparedStatement select = null;
        ResultSet rs = null;
        try{
            getConnexio();
            select = getConnexio().prepareStatement(query, ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
            select.setInt(1, id);
            
            rs = select.executeQuery();
        }catch (SQLException ex){
             JOptionPane.showMessageDialog(null,ex);           
        } finally{}
        
        return rs;
    }
    
    public static void closeConnexio(){
        try{
            if(conn != null && !conn.isClosed()){
                //Tanca la connexió a la base de dades
                conn.close();
            }
        } catch (SQLException ex){
             JOptionPane.showMessageDialog(null, ex);
        }
    }
    
}
