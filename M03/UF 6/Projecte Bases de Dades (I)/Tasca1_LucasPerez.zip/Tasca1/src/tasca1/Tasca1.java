/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tasca1;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Lucas
 */
public class Tasca1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws SQLException {
        // Equips
            Equips equips = new Equips();
            equips.obtenirEquips();
            
            Equip equip1 = equips.posterior();
            Equip equip2 = equips.posterior();
            
            System.out.println(equip1.toString());
            System.out.println(equip2.toString());
            equips.tancar();
        // Equips ID
            Equips equips1 = new Equips();
            equips1.obtenirEquips(1);
            
            Equip equip3 = equips1.posterior();
            Equip equip4 = equips1.posterior();
            
            System.out.println(equip3.toString());
            equips.tancar();
            
        // Jugadors
            Jugadors jugadors = new Jugadors();
            jugadors.obtenirJugadors();
            
            Jugador jugador1 = jugadors.posterior();
            Jugador jugador2 = jugadors.posterior();
            
            System.out.println(jugador1.toString());
            System.out.println(jugador2.toString());
            jugadors.tancar();
            
        // Jugadors ID
            Jugadors jugadors2 = new Jugadors();
            jugadors2.obtenirJugadorsByEquip(2);
            
            Jugador jugador3 = jugadors2.posterior();
            Jugador jugador4 = jugadors2.posterior();
            
            System.out.println(jugador3.toString());
            System.out.println(jugador4.toString());
            jugadors2.tancar();
    }
    
}
