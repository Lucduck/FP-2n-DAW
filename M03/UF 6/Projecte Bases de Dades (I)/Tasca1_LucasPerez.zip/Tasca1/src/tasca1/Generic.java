/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tasca1;

import java.util.ArrayList;
import java.util.Iterator;

/**
 *
 * @author Lucas
 */
public class Generic {
    public static String crearConsulta(String camps, String taules, ArrayList where, String camp_ordenacio) {
        String consulta = "";
        
        consulta += "SELECT " + camps;
        consulta += " FROM " + taules;
        
        
        if(where != null){ //mirar si hi ha un where
            Iterator<String> itWhere = where.iterator();   
            consulta += " WHERE ";
            
            while(itWhere.hasNext()){
                consulta += itWhere.next() + " = ? "; 
                if(itWhere.hasNext()){
                    consulta += "AND ";//mira si hi ha un next per posar un AND
                }
            }
        }
        
        if(camp_ordenacio != null){ //mirar si hi ha un metode de ordenació
            consulta += " ORDER BY " + camp_ordenacio;
        }
        
        return consulta;
    }
}
