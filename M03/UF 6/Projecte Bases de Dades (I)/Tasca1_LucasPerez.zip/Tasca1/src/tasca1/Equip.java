/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tasca1;
import java.util.ArrayList;
import java.util.Iterator;

/**
 *
 * @author Maribel
 */
public class Equip {
    /*Constants amb el nom dels camps*/
    public static final String E_TAULA = "EQUIPS";
    
    public static final String E_ID = "EQ_ID";
    public static final String E_NOM = "EQ_NOM";
    public static final String E_ESTADI = "ESTADI";
    public static final String E_POBL = "POBLACIO";
    public static final String E_CP = "COD_POSTAL";
    
    public static final String E_SELECT_ALL = E_ID + ", " + E_NOM + ", " + E_ESTADI + ", " + E_POBL + ", " + E_CP;
    
    private int id_equip;
    private String nom_equip;
    private String estadi;
    private String poblacio;
    private String codiPostal;
    
    
    public Equip(int id_equip, String nom_equip, String estadi, String poblacio, String codiPostal) {
        this.id_equip = id_equip;
        this.nom_equip = nom_equip;
        this.estadi = estadi;
        this.poblacio = poblacio;
        this.codiPostal = codiPostal;
    }
    public Equip() {
        this.id_equip = -1;
        this.nom_equip = null;
        this.estadi = null;
        this.poblacio = null;
        this.codiPostal = null;
    }


    public int getId_equip() {
        return id_equip;
    }

    public void setId_equip(int id_equip) {
        this.id_equip = id_equip;
    }

    public String getNom_equip() {
        return nom_equip;
    }

    public void setNom_equip(String nom_equip) {
        this.nom_equip = nom_equip;
    }

    public String getEstadi() {
        return estadi;
    }

    public void setEstadi(String estadi) {
        this.estadi = estadi;
    }

    public String getPoblacio() {
        return poblacio;
    }

    public void setPoblacio(String poblacio) {
        this.poblacio = poblacio;
    }

    public String getCodiPostal() {
        return codiPostal;
    }

    public void setCodiPostal(String codiPostal) {
        this.codiPostal = codiPostal;
    }

    @Override
    public String toString() {
        return "Equip{" + "id_equip=" + id_equip + ", nom_equip=" + nom_equip + ", estadi=" + estadi + ", poblacio=" + poblacio + ", codiPostal=" + codiPostal + '}';
    }
    
    public static String crearConsulta() {
        return crearConsulta(null, null);
    }
    
    public static String crearConsulta(ArrayList<String> camps) {
        return crearConsulta(camps, null);
    }
    
    public static String crearConsulta(ArrayList camps, String camp_ordenacio) {
        return Generic.crearConsulta(E_SELECT_ALL, E_TAULA, camps, camp_ordenacio);
    }
    
}
